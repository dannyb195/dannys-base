================================================================
The Journalist 1.9.9.9 - Designed by Lucian E. Marin | http://lucianmarin.com/
[Theme built for WordPress 2.3 � 2.8] 
[Licensed under GPL]
[September 9th 2009]

How to install
-----------------

You should be looking at the The Journalist folder right now if your reading this; if your not unzip the archive. You should than see a folder called journalist. 

Open up your FTP program and login to your server. Navigate to your WordPress folder and upload the entire folder (journalist) to your wp-content/themes folder.

Login to WordPress administration normally and select Presentation from the menu.

You should see a freshly installed theme called The Journalist 1.9 and a few basic details about the theme. 

Active this theme by clicking Select on the right.

View your site to see The Journalist in all his glory. 
	
Note: A page refresh may be required.


Extra
-----------------

+Browser support
I have tested The Journalist in the following browsers:

Firefox 1/2/3.5
Opera 8/9/10
Safari 2/3/4
Internet Explorer 6/7/8

+Credit
If you enjoy this theme please let me know; it only takes 5 minutes of your life. You can find details at: http://lucianmarin.com/


I hope you enjoy The Journalist - Lucian E. Marin
================================================================