</div>

<div id="footer">
	<p class="vcard">The Journalist template by <a href="http://lucianmarin.com/" class="fn url" rel="designer">Lucian E. Marin</a> &mdash; Built for <a href="http://wordpress.org/">WordPress</a></p>
</div>
<?php do_action('wp_footer', ''); ?>

</body>
</html>
